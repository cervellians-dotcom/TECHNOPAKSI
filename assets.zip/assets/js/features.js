
// Image Upload functionality
let selectedFile = null;
const dragArea = document.getElementById('dragArea');
const fileInput = document.getElementById('fileInput');

// Camera functionality
function openCamera() {
  // Create a new file input with camera capture
  const cameraInput = document.createElement('input');
  cameraInput.type = 'file';
  cameraInput.accept = 'image/*';
  cameraInput.capture = 'environment'; // Use back camera on mobile
  cameraInput.style.display = 'none';
  
  cameraInput.onchange = function(event) {
    const file = event.target.files[0];
    if (file) {
      handleFileSelect(file);
    }
  };
  
  // Add to DOM temporarily and trigger click
  document.body.appendChild(cameraInput);
  cameraInput.click();
  document.body.removeChild(cameraInput);
}

// Handle single file selection (for camera)
function handleFileSelect(file) {
  handleFiles([file]);
}

function startUpload() {
  document.getElementById('uploadModal').style.display = 'block';
}

function stopUpload() {
  document.getElementById('uploadModal').style.display = 'none';
  document.getElementById('uploadForm').reset();
  selectedFile = null;
  dragArea.innerHTML = `
    <p>Drag & drop gambar di sini atau</p>
    <div style="display: flex; gap: 10px; justify-content: center; margin-top: 10px;">
      <input type="file" id="fileInput" accept="image/*" style="display: none">
      <button onclick="document.getElementById('fileInput').click()" class="action-btn primary">📁 Pilih File</button>
      <button onclick="openCamera()" class="action-btn secondary">📷 Ambil Foto</button>
    </div>
  `;
  // Hide detection results
  document.getElementById('detectionResults').style.display = 'none';
}

function showDetectionResults(detection, originalImageUrl) {
  console.log('showDetectionResults called with:', detection, originalImageUrl);
  const resultsDiv = document.getElementById('detectionResults');
  const summaryDiv = document.getElementById('detectionSummary');
  const countsDiv = document.getElementById('detectionCounts');
  const originalDiv = document.getElementById('originalImage');
  const annotatedDiv = document.getElementById('annotatedImage');
  const errorDiv = document.getElementById('detectionError');
  
  console.log('Found elements:', { resultsDiv, summaryDiv, countsDiv, originalDiv, annotatedDiv, errorDiv });
  
  // Clear previous results
  summaryDiv.innerHTML = '';
  countsDiv.innerHTML = '';
  originalDiv.innerHTML = '';
  annotatedDiv.innerHTML = '';
  errorDiv.innerHTML = '';
  
  if (detection.error) {
    // Show error
    errorDiv.innerHTML = `❌ Error: ${detection.error}`;
    summaryDiv.innerHTML = 'Deteksi gagal';
  } else {
    // Show success results
    const summary = detection.summary || 'Tidak ada objek yang terdeteksi';
    summaryDiv.innerHTML = `✅ ${summary}`;
    
    // Show object counts
    if (detection.counts && Object.keys(detection.counts).length > 0) {
      let countsHtml = '<strong>Objek yang ditemukan:</strong><ul style="margin: 5px 0; padding-left: 20px;">';
      for (const [obj, count] of Object.entries(detection.counts)) {
        countsHtml += `<li>${obj}: ${count}</li>`;
      }
      countsHtml += '</ul>';
      countsDiv.innerHTML = countsHtml;
    } else {
      countsDiv.innerHTML = '<em>Tidak ada objek yang terdeteksi</em>';
    }
    
    // Show original image
    originalDiv.innerHTML = `
      <div style="text-align: center;">
        <h5 style="margin: 0 0 5px 0;">Gambar Asli</h5>
        <img src="${originalImageUrl}" style="max-width: 100%; max-height: 300px; height: auto; border-radius: 5px; border: 2px solid #ddd; object-fit: contain;">
      </div>
    `;
    
    // Show annotated image if available
    if (detection.annotated_url) {
      annotatedDiv.innerHTML = `
        <div style="text-align: center;">
          <h5 style="margin: 0 0 5px 0;">Hasil Deteksi</h5>
          <img src="${detection.annotated_url}" style="max-width: 100%; max-height: 300px; height: auto; border-radius: 5px; border: 2px solid #007bff; object-fit: contain;">
        </div>
      `;
    } else {
      annotatedDiv.innerHTML = '<div style="text-align: center; color: #666;"><em>Gambar hasil deteksi tidak tersedia</em></div>';
    }
  }
  
  // Show the results section
  console.log('Making results div visible');
  resultsDiv.style.display = 'block';
  
  // Add close button for results
  if (!resultsDiv.querySelector('.close-results-btn')) {
    const closeBtn = document.createElement('button');
    closeBtn.className = 'close-results-btn';
    closeBtn.innerHTML = '✕ Tutup Hasil';
    closeBtn.style.cssText = 'position: absolute; top: 10px; right: 10px; background: #dc3545; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; font-size: 12px;';
    closeBtn.onclick = () => {
      resultsDiv.style.display = 'none';
      stopUpload();
    };
    resultsDiv.style.position = 'relative';
    resultsDiv.appendChild(closeBtn);
  }
}

// Handle drag and drop
['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
  dragArea.addEventListener(eventName, preventDefaults, false);
});

function preventDefaults(e) {
  e.preventDefault();
  e.stopPropagation();
}

['dragenter', 'dragover'].forEach(eventName => {
  dragArea.addEventListener(eventName, highlight, false);
});

['dragleave', 'drop'].forEach(eventName => {
  dragArea.addEventListener(eventName, unhighlight, false);
});

function highlight(e) {
  dragArea.classList.add('active');
}

function unhighlight(e) {
  dragArea.classList.remove('active');
}

dragArea.addEventListener('drop', handleDrop, false);

function handleDrop(e) {
  const dt = e.dataTransfer;
  const files = dt.files;
  handleFiles(files);
}

fileInput.addEventListener('change', function() {
  handleFiles(this.files);
});

function handleFiles(files) {
  if (files.length > 0) {
    const file = files[0];
    
    // Check file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      alert('File terlalu besar. Maksimal ukuran file adalah 5MB.');
      return;
    }

    // Check file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!validTypes.includes(file.type)) {
      alert('Hanya file JPG, JPEG, dan PNG yang diperbolehkan.');
      return;
    }

    selectedFile = file;
    dragArea.innerHTML = `
      <p>File selected: ${selectedFile.name}</p>
      <small style="display:block;margin:5px 0;color:#666">
        Size: ${(selectedFile.size / 1024 / 1024).toFixed(2)}MB
      </small>
      <button onclick="document.getElementById('fileInput').click()" class="action-btn primary">Change File</button>
    `;
  }
}

async function handleUpload(e) {
  e.preventDefault();
  if (!selectedFile) {
    alert('Silakan pilih file gambar terlebih dahulu');
    return;
  }

  const formData = new FormData();
  formData.append('image', selectedFile);
  formData.append('description', 'Image upload');

  try {
    // Show loading state
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Mengupload...';

    console.log('🚀 Starting upload to:', config.api.uploads);
    console.log('📤 FormData contents:', Array.from(formData.entries()));

    const result = await apiCall(config.api.uploads, {
      method: 'POST',
      body: formData,
      headers: {} // Let the browser set the correct Content-Type for FormData
    });
    
    // Update points display with the new total
    document.getElementById('userPoints').textContent = result.total_points;
    
    // Update navbar points
    if (typeof updateNavbarPoints === 'function') {
      updateNavbarPoints(result.total_points);
    }
    
    // Show detection results in modal
    console.log('Upload result:', result);
    if (result.detection) {
      console.log('Showing detection results:', result.detection);
      showDetectionResults(result.detection, result.image_url);
    } else {
      console.log('No detection data, showing alert');
      alert(`Upload berhasil! Anda mendapatkan ${result.points_earned || 10} poin`);
      stopUpload();
    }
  } catch (err) {
    console.error('❌ Error uploading image:', err);
    console.error('❌ Error details:', {
      message: err.message,
      stack: err.stack,
      name: err.name
    });
    alert(`Upload failed: ${err.message || 'Gagal mengupload gambar'}`);
  } finally {
    // Reset button state
    submitBtn.disabled = false;
    submitBtn.textContent = originalText;
  }
} 

// ================= Methane polling and UI update =================
async function fetchLatestMethane() {
  try {
    return await apiCall(config.api.methaneLatest);
  } catch (e) {
    return { ppm: null, status: 'unknown', created_at: null };
  }
}

function currentLang() {
  return localStorage.getItem('lang') || 'id';
}

function t(key) {
  try { return (window.translations?.[currentLang()]?.[key]) || key; } catch { return key; }
}

function formatTimeAgo(iso) {
  if (!iso) return '-';
  const dt = new Date(iso);
  const diff = Math.floor((Date.now() - dt.getTime()) / 1000);
  const lang = currentLang();
  if (diff < 60) return lang === 'en' ? `${diff}s ago` : `${diff}s lalu`;
  if (diff < 3600) return lang === 'en' ? `${Math.floor(diff/60)}m ago` : `${Math.floor(diff/60)}m lalu`;
  if (diff < 86400) return lang === 'en' ? `${Math.floor(diff/3600)}h ago` : `${Math.floor(diff/3600)}j lalu`;
  return dt.toLocaleString(lang === 'en' ? 'en-US' : 'id-ID');
}

function setBadge(statusEl, status) {
  const map = {
    normal: { bg: '#DFF5E1', fg: '#1F7A3E', text: t('methane.status.normal') },
    warning: { bg: '#FFF5CC', fg: '#7A5B00', text: t('methane.status.warning') },
    danger: { bg: '#FDE2E1', fg: '#B3261E', text: t('methane.status.danger') },
    unknown: { bg: '#eee', fg: '#49260A', text: t('methane.status.unknown') }
  };
  const s = map[status] || map.unknown;
  statusEl.style.background = s.bg;
  statusEl.style.color = s.fg;
  statusEl.textContent = s.text;
}

async function updateMethaneUI() {
  const sec = document.getElementById('methaneSection');
  if (!sec) return;
  const { ppm, status, created_at } = await fetchLatestMethane();
  const ppmEl = document.getElementById('methanePpm');
  const timeEl = document.getElementById('methaneUpdated');
  const badge = document.getElementById('methaneStatusBadge');
  ppmEl.textContent = ppm == null ? '-' : Number(ppm).toFixed(1);
  timeEl.textContent = formatTimeAgo(created_at);
  setBadge(badge, status);
}

function startMethanePolling() {
  if (!document.getElementById('methaneSection')) return;
  updateMethaneUI();
  setInterval(updateMethaneUI, 10000);
}

// Auto-start polling on pages that include the section
try { startMethanePolling(); } catch (e) {}