// API Configuration
const API_URL = 'https://4aee02bcdc27.ngrok-free.app/api';

const config = {
  api: {
    register: `${API_URL}/register`,
    login: `${API_URL}/login`,
    profile: `${API_URL}/profile`,
    locations: `${API_URL}/locations`,
    vouchers: `${API_URL}/vouchers`,
    availableVouchers: `${API_URL}/vouchers/available`,
    redeemVoucher: `${API_URL}/vouchers/redeem`,
    // Admin endpoints
    adminStats: `${API_URL}/admin/stats`,
    // Upload endpoints
    uploads: `${API_URL}/uploads`,
    // Methane endpoints
    methaneLatest: `${API_URL}/methane/latest`
  }
};

// Helper function to make authenticated API calls
async function apiCall(endpoint, options = {}) {
  // Set a mock token for testing
  const token = localStorage.getItem('token') || 'mock-admin-token-' + Date.now();
  
  const defaultOptions = {
    headers: {
      ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    }
  };

  // If the body is FormData, don't set Content-Type (browser will set it with boundary)
  if (!(options.body instanceof FormData)) {
    defaultOptions.headers['Content-Type'] = 'application/json';
    if (options.body) {
      options.body = JSON.stringify(options.body);
    }
  }

  try {
    const response = await fetch(endpoint, { 
      ...defaultOptions, 
      ...options,
      headers: {
        ...defaultOptions.headers,
        ...(options.headers || {})
      }
    });

    // Check if the response is JSON
    const contentType = response.headers.get('content-type');
    let data;
    
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      data = await response.text();
    }

    if (!response.ok) {
      throw new Error(data.error || 'Something went wrong');
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

// Expose to window
window.config = config;
window.apiCall = apiCall; 