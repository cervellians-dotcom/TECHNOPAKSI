# FoodFlow - Sistem Manajemen Sampah Makanan

Aplikasi web untuk mengelola sampah makanan dengan sistem poin dan voucher. Pengguna dapat mengumpulkan poin melalui scan QR code atau upload bukti pembuangan sampah makanan.

## 📋 Fitur Utama

- 👤 Sistem Autentikasi (Login/Register)
- 📱 Dashboard Pengguna
- 🎯 Sistem Poin
- 📷 Upload Bukti Gambar
- 📱 Scan QR Code
- 🗺️ Peta Lokasi Toko
- 🎫 Manajemen Voucher
- 👨‍💼 Panel Admin

## 🔧 Persyaratan Sistem

- Node.js (versi 14 atau lebih baru)
- MySQL (versi 5.7 atau lebih baru)
- Web Browser Modern (Chrome, Firefox, Safari, Edge)

## ⚙️ Instalasi

1. Ekstrak File

2. Install dependensi:
```bash
`npm install`
```

3. Buat database MySQL baru dengan nama `foodflow_db`

4. Buat file `.env` di root project:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=password_anda
DB_NAME=foodflow_db
JWT_SECRET=kunci_rahasia_anda
PORT=3000
```

5. Import struktur database:
```bash
mysql -u root -p foodflow_db < database.sql
```

6. Buat folder untuk upload gambar:
```bash
mkdir -p public/uploads
```

## 🚀 Menjalankan Aplikasi

1. Mode Development:
```bash
npm run dev
```

2. Mode Production:
```bash
npm start
```

Aplikasi akan berjalan di `http://localhost:3000`

## 👥 Akun Default

### Admin
- Username: admin
- Password: admin123

### Demo User
- Username: demo
- Password: demo

## 📱 Cara Penggunaan

### Untuk Pengguna

1. **Registrasi & Login**
   - Buka halaman web
   - Klik "Daftar" untuk membuat akun baru
   - Login menggunakan username dan password

2. **Mengumpulkan Poin**
   - Scan QR Code voucher dari toko mitra
   - Upload bukti pembuangan sampah makanan
   - Setiap upload bukti mendapatkan 10 poin

3. **Melihat Lokasi Toko**
   - Klik menu "Peta" untuk melihat lokasi toko mitra
   - Gunakan fitur filter untuk mencari toko terdekat
   - Klik toko untuk melihat detail dan petunjuk arah

### Untuk Admin

1. **Akses Panel Admin**
   - Login sebagai admin
   - Klik menu "Admin" di navbar

2. **Mengelola Lokasi**
   - Buka menu "Kelola Lokasi"
   - Tambah lokasi baru dengan mengklik peta
   - Isi detail lokasi (nama, alamat)
   - Hapus lokasi yang tidak aktif

3. **Mengelola Voucher**
   - Buka menu "Kelola Voucher"
   - Generate voucher baru (poin/diskon)
   - Atur jumlah dan masa berlaku voucher
   - Pantau penggunaan voucher

## 📁 Struktur Folder

```
foodflow/
├── public/              # File statis
│   ├── assets/         # Asset (CSS, JS, gambar)
│   ├── components/     # Komponen HTML
│   └── uploads/        # Folder upload gambar
├── server.js           # File utama server
├── database.sql        # Struktur database
├── package.json        # Dependensi project
└── .env               # Konfigurasi environment
```

## 📡 Deteksi Gas Metana

Frontend menampilkan status metana pada beranda (di dalam kotak putih alamat utama). Data diambil setiap 10 detik dari endpoint backend.

### Endpoint Backend

- GET `/api/methane/latest`
  - Respon: `{ ppm: number|null, status: 'normal'|'warning'|'danger'|'unknown', created_at: string|null }`
- POST `/api/methane`
  - Body JSON: `{ key: string, ppm: number }`
  - `key` adalah kunci perangkat. Set di `.env` sebagai `METHANE_DEVICE_KEY`. Jika tidak diset, server membuat kunci default saat start (gunakan nilai itu untuk perangkat).
  - Status dihitung otomatis dari `ppm` (warning ≥ 500, danger ≥ 1000). Ubah ambang di `server.js` bila perlu.

Contoh kirim data dari perangkat:

```bash
curl -X POST http://127.0.0.1:3000/api/methane \
  -H "Content-Type: application/json" \
  -d '{"key":"REPLACE_WITH_KEY","ppm": 650.4}'
```

Nilai ini akan langsung tampil di badge status metana.

## 🔒 Keamanan

- Gunakan password yang kuat
- Ganti `JWT_SECRET` di file `.env`
- Batasi akses ke folder `uploads`
- Update dependensi secara berkala

## 📝 Catatan Penting

- Ukuran maksimal file upload: 5MB
- Format gambar yang didukung: JPG, JPEG, PNG
- Backup database secara berkala
- Pastikan folder `uploads` memiliki permission yang benar

## 🐛 Troubleshooting

1. **Error "ECONNREFUSED"**
   - Pastikan MySQL berjalan
   - Cek konfigurasi di `.env`

2. **Error Upload File**
   - Cek ukuran file (max 5MB)
   - Pastikan format file sesuai
   - Cek permission folder `uploads`

3. **QR Code Tidak Terbaca**
   - Pastikan pencahayaan cukup
   - Posisikan QR code dalam frame
   - Gunakan kamera yang bersih
