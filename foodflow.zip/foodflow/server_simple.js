require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const { spawnSync } = require('child_process');

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Configure multer for image upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = 'public/uploads';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
    files: 1
  },
  fileFilter: function (req, file, cb) {
    const filetypes = /jpeg|jpg|png/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
  }
});

// Simple authentication middleware (for testing)
const authenticateToken = (req, res, next) => {
  // For testing, we'll just set a mock user - no token validation needed
  req.user = { id: 1, username: 'testuser', role: 'user' };
  next();
};

// Image Upload with ML Detection
app.post('/api/uploads', authenticateToken, (req, res) => {
  upload.single('image')(req, res, async function(err) {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ 
          error: 'File terlalu besar. Maksimal ukuran file adalah 5MB.' 
        });
      }
      return res.status(400).json({ error: err.message });
    } else if (err) {
      return res.status(400).json({ error: err.message });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'No image file provided' });
    }

    try {
      const description = req.body.description || 'Image upload';
      const imageUrl = `/uploads/${req.file.filename}`;
      const imageAbsPath = path.join(__dirname, 'public', 'uploads', req.file.filename);

      // Run ML detection
      let detection = null;
      try {
        const modelPath = path.join(__dirname, '..', 'my_model (4)', 'train', 'weights', 'best.pt');
        const detectScript = path.join(__dirname, '..', 'my_model (4)', 'detect_api.py');
        const annotatedDir = path.join(__dirname, 'public', 'uploads', 'annotated');
        if (!fs.existsSync(annotatedDir)) fs.mkdirSync(annotatedDir, { recursive: true });
        const annotatedFilename = req.file.filename.replace(path.extname(req.file.filename), '_det.jpg');
        const annotatedAbs = path.join(annotatedDir, annotatedFilename);

        const pythonCmd = process.env.PYTHON_BIN || 'python';
        const args = [
          detectScript,
          '--model', modelPath,
          '--source', imageAbsPath,
          '--min_conf', '0.25',
          '--save_annotated', annotatedAbs
        ];

        console.log('Running detection:', pythonCmd, args.join(' '));
        const result = spawnSync(pythonCmd, args, { encoding: 'utf-8', windowsHide: true });
        
        if (result.error) {
          throw result.error;
        }
        
        const stdout = (result.stdout || '').trim();
        if (stdout) {
          detection = JSON.parse(stdout);
          if (detection && detection.annotated_path) {
            const rel = path.relative(path.join(__dirname, 'public'), detection.annotated_path).replace(/\\/g, '/');
            detection.annotated_url = `/${rel}`;
          }
        }
      } catch (mlErr) {
        console.warn('ML detection failed:', mlErr?.message || mlErr);
        detection = { error: 'Detection failed: ' + (mlErr?.message || 'Unknown error') };
      }

      res.status(201).json({
        message: 'Upload successful',
        upload_id: Date.now(),
        points_earned: 10,
        total_points: 100, // Mock points for testing
        image_url: imageUrl,
        detection
      });
    } catch (err) {
      console.error('Upload error:', err);
      res.status(500).json({ error: err.message });
    }
  });
});

// Mock login endpoint for testing
app.post('/api/login', (req, res) => {
  const token = 'mock-token-for-testing';
  res.json({
    token,
    user: {
      id: 1,
      username: 'testuser',
      fullname: 'Test User',
      email: 'test@example.com',
      role: 'user',
      points: 100
    }
  });
});

// Mock profile endpoint
app.get('/api/profile', authenticateToken, (req, res) => {
  res.json({
    id: 1,
    username: 'testuser',
    fullname: 'Test User',
    email: 'test@example.com',
    role: 'user',
    points: 100
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log('Note: This is a simplified server for testing ML detection');
  console.log('Make sure Python and ultralytics are installed:');
  console.log('python -m pip install ultralytics opencv-python');
});
