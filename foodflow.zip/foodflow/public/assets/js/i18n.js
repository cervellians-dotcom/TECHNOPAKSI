// Translations object
const translations = {
  id: {
    'nav.home': 'Beranda',
    'nav.stores': 'Toko',
    'nav.store': 'Toko',
    'nav.map': 'Peta',
    'nav.admin': 'Admin Panel',
    'nav.profile': 'Profil',
    'nav.logout': 'Keluar',
    'map.title': 'Peta Toko',
    'map.useMyLocation': 'Gunakan Lokasi Saya',
    'hero.title': 'Mari buang sampah hari ini!',
    'hero.desc': 'Sudahkah kamu membuang sampah hari ini? Kelola sampah makananmu dan kumpulkan poin dari mitra restoran di sekitar.',
    'hero.addressTitle': 'Alamat Utama',
    'hero.methaneTitle': 'Status Metana',
    'hero.methaneDesc': 'Status metana saat ini',
    'stats.points': 'Poin Terkumpul',
    'stats.users': 'Pengguna Aktif',
    'stats.transactions': 'Transaksi',
    'store.title': 'Rekomendasi',
    'store.more': 'Lihat Semua ›',
    // Methane
    'methane.title': 'Deteksi Gas Metana',
    'methane.loading': 'Memuat...',
    'methane.level': 'Kadar',
    'methane.last': 'Terakhir',
    'methane.status.normal': 'Aman',
    'methane.status.warning': 'Waspada',
    'methane.status.danger': 'Bahaya',
    'methane.status.unknown': 'Tidak diketahui',
    // FAQ
    'faq.title': 'Pertanyaan yang Sering Diajukan',
    'faq.q1': 'Apa itu FoodFlow?',
    'faq.a1': 'FoodFlow adalah tempat sampah pintar bertenaga AI yang dirancang untuk bisnis kuliner. Alat ini mendeteksi sampah makanan, memprosesnya melalui beberapa wadah, dan mengubahnya menjadi biogas yang dapat digunakan untuk gas portabel dan listrik.',
    'faq.q2': 'Siapa yang dapat merasakan manfaat dari penggunaan FoodFlow?',
    'faq.a2': 'FoodFlow sangat cocok untuk restoran, hotel, layanan katering, supermarket, dan pusat jajanan — bisnis apa pun yang menghasilkan limbah makanan secara rutin dan ingin mengurangi biaya, menekan jumlah sampah, serta bergerak menuju keberlanjutan.',
    'faq.q3': 'Apa saja manfaat menggunakan FoodFlow?',
    'faq.a3': '- Mengurangi volume limbah makanan.\n- Menurunkan biaya pembuangan sampah.\n- Menghasilkan biogas bersih dan terbarukan untuk memasak dan listrik.\n- Menjaga dapur tetap bersih dan efisien.',
    'faq.q4': 'Bagaimana FoodFlow membantu lingkungan?',
    'faq.a4': 'Dengan mengubah limbah menjadi energi, FoodFlow mengurangi kontribusi ke tempat pembuangan akhir, menekan emisi metana, dan mendorong terciptanya ekonomi sirkular.',
    'faq.q5': 'Bagaimana cara mendapatkan poin?',
    'faq.a5': 'Anda bisa scan QR atau upload bukti pembuangan sampah makanan.',
    'faq.q6': 'Apakah data lokasi saya disimpan?',
    'faq.a6': 'Lokasi hanya digunakan untuk menampilkan peta dan tidak disimpan di server.',
    'faq.q7': 'Apa arti status metana?',
    'faq.a7': 'Aman: normal, Waspada: sedang meningkat, Bahaya: melebihi ambang batas.',

  },
  en: {
    'nav.home': 'Home',
    'nav.stores': 'Stores',
    'nav.store': 'Stores',
    'nav.map': 'Map',
    'nav.admin': 'Admin Panel',
    'nav.profile': 'Profile',
    'nav.logout': 'Logout',
    'map.title': 'Store Map',
    'map.useMyLocation': 'Use My Location',
    'hero.title': 'Let\'s dispose waste today!',
    'hero.desc': 'Have you disposed of your waste today? Manage your food waste and collect points from partner restaurants around.',
    'hero.addressTitle': 'Main Address',
    'hero.methaneTitle': 'Methane Status',
    'hero.methaneDesc': 'Current methane status',
    'stats.points': 'Points Collected',
    'stats.users': 'Active Users',
    'stats.transactions': 'Transactions',
    'store.title': 'Recommendations',
    'store.more': 'View All ›',
    // Methane
    'methane.title': 'Methane Detection',
    'methane.loading': 'Loading...',
    'methane.level': 'Level',
    'methane.last': 'Last',
    'methane.status.normal': 'Safe',
    'methane.status.warning': 'Warning',
    'methane.status.danger': 'Danger',
    'methane.status.unknown': 'Unknown',
    // FAQ
    'faq.title': 'Frequently Asked Questions',
    'faq.q1': 'What is FoodFlow?',
    'faq.a1': 'FoodFlow is an AI-powered smart trashcan designed for culinary businesses. It detects food waste, processes it through multiple trays, and converts it into biogas that can be used for portable gas and electricity.',
    'faq.q2': 'Who can benefit from using FoodFlow?',
    'faq.a2': 'FoodFlow is ideal for restaurants, hotels, catering services, supermarkets, and food courts — any business that generates regular food waste and wants to reduce costs, cut down on trash, and move toward sustainability.',
    'faq.q3': 'What are the benefits of using FoodFlow?',
    'faq.a3': 'Reducing food waste volume.\nLowering disposal costs.\nProducing clean and renewable biogas for cooking and electricity.\nKeeping the kitchen clean and efficient.',
    'faq.q4': 'How does FoodFlow help the environment?',
    'faq.a4': 'By converting waste into energy, FoodFlow reduces its contribution to final disposal sites, reduces methane emissions, and promotes circular economy.',
    'faq.q5': 'How do I earn points?',
    'faq.a5': 'You can scan a QR or upload proof of food waste disposal.',
    'faq.q6': 'Is my location data stored?',
    'faq.a6': 'Location is only used to render the map and is not stored on the server.',
    'faq.q7': 'What do methane statuses mean?',
    'faq.a7': 'Safe: normal, Warning: rising, Danger: above threshold.'
  }
};

// Set language function
function setLanguage(lang) {
  if (!translations[lang]) return;
  
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n');
    if (translations[lang][key]) {
      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
        element.placeholder = translations[lang][key];
      } else {
        element.textContent = translations[lang][key];
      }
    }
  });
  
  localStorage.setItem('lang', lang);
  const switcher = document.getElementById('langSwitch');
  if (switcher) switcher.value = lang;
}

// Initialize with saved language or default to Indonesian
document.addEventListener('DOMContentLoaded', () => {
  const savedLang = localStorage.getItem('lang') || 'id';
  setLanguage(savedLang);
});