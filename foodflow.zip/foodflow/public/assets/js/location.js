/**
 * Location Detection Service for FoodFlow
 * Handles geolocation, reverse geocoding, and location-based features
 */

class LocationService {
  constructor() {
    this.currentLocation = null;
    this.currentAddress = null;
    this.watchId = null;
    this.callbacks = [];
    this.isSupported = 'geolocation' in navigator;
    this.options = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 300000 // 5 minutes
    };
  }

  /**
   * Get current location with permission request
   */
  async getCurrentLocation() {
    return new Promise((resolve, reject) => {
      if (!this.isSupported) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          this.currentLocation = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp
          };

          try {
            // Get address from coordinates
            this.currentAddress = await this.reverseGeocode(
              this.currentLocation.latitude,
              this.currentLocation.longitude
            );
            
            this.notifyCallbacks();
            resolve({
              location: this.currentLocation,
              address: this.currentAddress
            });
          } catch (error) {
            console.warn('Reverse geocoding failed:', error);
            resolve({
              location: this.currentLocation,
              address: null
            });
          }
        },
        (error) => {
          this.handleLocationError(error);
          reject(error);
        },
        this.options
      );
    });
  }

  /**
   * Start watching location changes
   */
  startWatching() {
    if (!this.isSupported) {
      console.warn('Geolocation is not supported');
      return;
    }

    this.watchId = navigator.geolocation.watchPosition(
      async (position) => {
        this.currentLocation = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp
        };

        try {
          this.currentAddress = await this.reverseGeocode(
            this.currentLocation.latitude,
            this.currentLocation.longitude
          );
        } catch (error) {
          console.warn('Reverse geocoding failed:', error);
        }

        this.notifyCallbacks();
      },
      (error) => {
        this.handleLocationError(error);
      },
      this.options
    );
  }

  /**
   * Stop watching location changes
   */
  stopWatching() {
    if (this.watchId) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
  }

  /**
   * Reverse geocoding to get address from coordinates
   */
  async reverseGeocode(lat, lng) {
    try {
      // Using OpenStreetMap Nominatim API (free)
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1&accept-language=id`
      );
      
      if (!response.ok) {
        throw new Error('Reverse geocoding failed');
      }

      const data = await response.json();
      
      if (data && data.display_name) {
        return {
          displayName: data.display_name,
          address: data.address,
          formatted: this.formatAddress(data.address)
        };
      }
      
      return null;
    } catch (error) {
      console.error('Reverse geocoding error:', error);
      throw error;
    }
  }

  /**
   * Format address for display
   */
  formatAddress(address) {
    if (!address) return 'Lokasi tidak diketahui';
    
    const parts = [];
    
    if (address.house_number) parts.push(address.house_number);
    if (address.road) parts.push(address.road);
    if (address.suburb) parts.push(address.suburb);
    if (address.city || address.town) parts.push(address.city || address.town);
    if (address.state) parts.push(address.state);
    if (address.postcode) parts.push(address.postcode);
    
    return parts.join(', ');
  }

  /**
   * Calculate distance between two coordinates (in km)
   */
  calculateDistance(lat1, lng1, lat2, lng2) {
    const R = 6371; // Earth's radius in km
    const dLat = this.toRadians(lat2 - lat1);
    const dLng = this.toRadians(lng2 - lng1);
    
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
              Math.sin(dLng / 2) * Math.sin(dLng / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  /**
   * Convert degrees to radians
   */
  toRadians(degrees) {
    return degrees * (Math.PI / 180);
  }

  /**
   * Handle location errors
   */
  handleLocationError(error) {
    let message = 'Error getting location: ';
    
    switch (error.code) {
      case error.PERMISSION_DENIED:
        message += 'Akses lokasi ditolak. Silakan izinkan akses lokasi untuk fitur ini.';
        break;
      case error.POSITION_UNAVAILABLE:
        message += 'Informasi lokasi tidak tersedia.';
        break;
      case error.TIMEOUT:
        message += 'Permintaan lokasi timeout.';
        break;
      default:
        message += 'Error tidak diketahui.';
        break;
    }
    
    console.error(message);
    this.showLocationError(message);
  }

  /**
   * Show location error to user
   */
  showLocationError(message) {
    // Create error notification
    const errorDiv = document.createElement('div');
    errorDiv.className = 'location-error';
    errorDiv.innerHTML = `
      <div class="location-error-content">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/>
          <line x1="12" y1="8" x2="12" y2="12"/>
          <line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <span>${message}</span>
        <button onclick="this.parentElement.parentElement.remove()" class="location-error-close">×</button>
      </div>
    `;
    
    // Add styles
    errorDiv.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #ff4444;
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 10000;
      max-width: 300px;
      animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(errorDiv);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      if (errorDiv.parentElement) {
        errorDiv.remove();
      }
    }, 5000);
  }

  /**
   * Subscribe to location updates
   */
  onLocationUpdate(callback) {
    this.callbacks.push(callback);
    
    // If we already have location, call immediately
    if (this.currentLocation) {
      callback({
        location: this.currentLocation,
        address: this.currentAddress
      });
    }
  }

  /**
   * Unsubscribe from location updates
   */
  offLocationUpdate(callback) {
    const index = this.callbacks.indexOf(callback);
    if (index > -1) {
      this.callbacks.splice(index, 1);
    }
  }

  /**
   * Notify all callbacks
   */
  notifyCallbacks() {
    this.callbacks.forEach(callback => {
      try {
        callback({
          location: this.currentLocation,
          address: this.currentAddress
        });
      } catch (error) {
        console.error('Error in location callback:', error);
      }
    });
  }

  /**
   * Get nearby stores based on current location
   */
  async getNearbyStores(radius = 5) {
    if (!this.currentLocation) {
      throw new Error('No current location available');
    }

    try {
      // This would typically call your API
      const response = await fetch(`/api/stores/nearby?lat=${this.currentLocation.latitude}&lng=${this.currentLocation.longitude}&radius=${radius}`);
      const stores = await response.json();
      
      // Calculate distances and sort
      return stores.map(store => ({
        ...store,
        distance: this.calculateDistance(
          this.currentLocation.latitude,
          this.currentLocation.longitude,
          store.latitude,
          store.longitude
        )
      })).sort((a, b) => a.distance - b.distance);
    } catch (error) {
      console.error('Error fetching nearby stores:', error);
      return [];
    }
  }

  /**
   * Check if location permission is granted
   */
  async checkPermission() {
    if (!navigator.permissions) {
      return 'unknown';
    }

    try {
      const permission = await navigator.permissions.query({ name: 'geolocation' });
      return permission.state;
    } catch (error) {
      return 'unknown';
    }
  }

  /**
   * Request location permission
   */
  async requestPermission() {
    try {
      await this.getCurrentLocation();
      return true;
    } catch (error) {
      return false;
    }
  }
}

// Create global instance
window.locationService = new LocationService();

// Add CSS for error notifications
const style = document.createElement('style');
style.textContent = `
  @keyframes slideInRight {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  .location-error-content {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .location-error-close {
    background: none;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
    padding: 0;
    margin-left: auto;
  }
  
  .location-status {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: rgba(255, 255, 255, 0.9);
    border-radius: 20px;
    font-size: 14px;
    color: var(--c-brown);
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  }
  
  .location-status.loading {
    color: var(--c-orange);
  }
  
  .location-status.success {
    color: #22c55e;
  }
  
  .location-status.error {
    color: #ef4444;
  }
  
  .location-indicator {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: currentColor;
    animation: pulse 2s infinite;
  }
  
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
`;
document.head.appendChild(style);

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = LocationService;
}
