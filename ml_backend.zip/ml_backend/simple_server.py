#!/usr/bin/env python3
"""
Simple working server for FoodFlow
"""

import os
import sys
import json
import cgi
import uuid
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

class SimpleHandler(BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # Set up directories
        self.upload_dir = Path(__file__).parent.parent / "foodflow" / "public" / "uploads"
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        super().__init__(*args, **kwargs)
    
    def do_GET(self):
        """Handle GET requests"""
        if self.path == '/':
            self.serve_file('../foodflow/public/index.html')
        elif self.path.startswith('/assets/'):
            self.serve_file(f'../foodflow/public{self.path}')
        elif self.path.startswith('/uploads/'):
            self.serve_file(f'../foodflow/public{self.path}')
        elif self.path == '/api/profile':
            self.send_json_response({"id": 1, "username": "user", "points": 100})
        elif self.path == '/api/locations':
            locations = [
                {"id": 1, "name": "Warung Makan Sederhana", "address": "Jl. Sudirman No. 123, Jakarta", "lat": -6.2088, "lng": 106.8456},
                {"id": 2, "name": "Restoran Padang Minang", "address": "Jl. Thamrin No. 456, Jakarta", "lat": -6.1944, "lng": 106.8229}
            ]
            self.send_json_response(locations)
        else:
            self.send_error(404)
    
    def do_POST(self):
        """Handle POST requests"""
        if self.path == '/api/uploads':
            self.handle_upload()
        else:
            self.send_error(404)
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()
    
    def handle_upload(self):
        """Handle image upload"""
        try:
            print("📸 Received upload request")
            
            # Parse multipart form data
            content_type = self.headers.get('content-type', '')
            if not content_type.startswith('multipart/form-data'):
                self.send_error(400, "Expected multipart/form-data")
                return
            
            # Parse form data
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={'REQUEST_METHOD': 'POST'}
            )
            
            if 'image' not in form:
                self.send_error(400, "No image provided")
                return
            
            file_item = form['image']
            if not file_item.filename:
                self.send_error(400, "No filename provided")
                return
            
            # Generate unique filename
            file_ext = Path(file_item.filename).suffix
            filename = f"{uuid.uuid4().hex}{file_ext}"
            filepath = self.upload_dir / filename
            
            # Save uploaded file
            print(f"💾 Saving image to: {filepath}")
            with open(filepath, 'wb') as f:
                f.write(file_item.file.read())
            
            # Mock ML detection response
            detection = {
                "summary": "Detected 3 objects",
                "counts": {"bottle": 2, "can": 1},
                "detections": [
                    {"class": "bottle", "confidence": 0.95, "bbox": [100, 100, 200, 300]},
                    {"class": "bottle", "confidence": 0.87, "bbox": [300, 150, 400, 350]},
                    {"class": "can", "confidence": 0.92, "bbox": [500, 200, 600, 400]}
                ]
            }
            
            # Return response
            response = {
                "message": "Upload successful",
                "image_url": f"/uploads/{filename}",
                "detection": detection,
                "total_points": 110
            }
            
            self.send_json_response(response)
            
        except Exception as e:
            print(f"❌ Upload error: {e}")
            self.send_error(500, str(e))
    
    def serve_file(self, filepath):
        """Serve static files"""
        try:
            with open(filepath, 'rb') as f:
                content = f.read()
            
            # Determine content type
            if filepath.endswith('.html'):
                content_type = 'text/html'
            elif filepath.endswith('.css'):
                content_type = 'text/css'
            elif filepath.endswith('.js'):
                content_type = 'application/javascript'
            elif filepath.endswith('.png'):
                content_type = 'image/png'
            elif filepath.endswith('.jpg') or filepath.endswith('.jpeg'):
                content_type = 'image/jpeg'
            else:
                content_type = 'application/octet-stream'
            
            self.send_response(200)
            self.send_header('Content-type', content_type)
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(content)
            
        except FileNotFoundError:
            self.send_error(404)
        except Exception as e:
            print(f"❌ File serve error: {e}")
            self.send_error(500)
    
    def send_json_response(self, data):
        """Send JSON response"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())
    
    def send_cors_headers(self):
        """Send CORS headers"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

if __name__ == '__main__':
    print("🚀 Starting Simple FoodFlow Server")
    print("📡 Server: http://localhost:3000")
    print("==================================================")
    
    server = HTTPServer(('localhost', 3000), SimpleHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server stopped")
        server.shutdown()
