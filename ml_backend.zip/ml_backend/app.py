#!/usr/bin/env python3
"""
FoodFlow ML Backend Server
Handles image uploads and runs YOLO detection
"""

import os
import sys
import json
import base64
import tempfile
import subprocess
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import cgi
import uuid
from datetime import datetime

# Add model directory to path
model_dir = Path(__file__).parent.parent / "my_model (4)"
sys.path.insert(0, str(model_dir))

class MLHandler(BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.upload_dir = Path(__file__).parent.parent / "foodflow" / "public" / "uploads"
        self.annotated_dir = self.upload_dir / "annotated"
        self.model_path = model_dir / "train" / "weights" / "best.pt"
        self.detect_script = model_dir / "detect_api.py"
        
        # Create directories
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.annotated_dir.mkdir(parents=True, exist_ok=True)
        
        super().__init__(*args, **kwargs)
    
    def do_GET(self):
        """Handle GET requests - serve static files"""
        if self.path == '/':
            self.serve_file('../foodflow/public/index.html')
        elif self.path.startswith('/assets/'):
            self.serve_file(f'../foodflow/public{self.path}')
        elif self.path.startswith('/uploads/'):
            self.serve_file(f'../foodflow/public{self.path}')
        elif self.path == '/api/locations':
            self.handle_locations()
        else:
            self.send_error(404)
    
    def do_POST(self):
        """Handle POST requests - API endpoints"""
        if self.path == '/api/uploads':
            self.handle_upload()
        elif self.path == '/api/login':
            self.handle_login()
        elif self.path == '/api/profile':
            self.handle_profile()
        elif self.path == '/api/locations':
            self.handle_locations()
        else:
            self.send_error(404)
    
    def do_DELETE(self):
        """Handle DELETE requests"""
        if self.path.startswith('/api/locations/'):
            self.handle_locations()
        else:
            self.send_error(404)
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()
    
    def serve_file(self, filepath):
        """Serve static files"""
        try:
            with open(filepath, 'rb') as f:
                content = f.read()
            
            # Set content type based on file extension
            content_type = 'application/octet-stream'
            if filepath.endswith('.html'):
                content_type = 'text/html; charset=utf-8'
            elif filepath.endswith('.js'):
                content_type = 'application/javascript'
            elif filepath.endswith('.css'):
                content_type = 'text/css'
            elif filepath.endswith(('.jpg', '.jpeg')):
                content_type = 'image/jpeg'
            elif filepath.endswith('.png'):
                content_type = 'image/png'
            
            self.send_response(200)
            self.send_header('Content-type', content_type)
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(content)
            
        except FileNotFoundError:
            self.send_error(404)
    
    def handle_login(self):
        """Mock login endpoint"""
        response = {
            "token": "ml-backend-token",
            "user": {
                "id": 1,
                "username": "mluser",
                "fullname": "ML User",
                "email": "ml@foodflow.com",
                "role": "user",
                "points": 100
            }
        }
        self.send_json_response(response)
    
    def handle_profile(self):
        """Mock profile endpoint"""
        response = {
            "id": 1,
            "username": "mluser",
            "fullname": "ML User",
            "email": "ml@foodflow.com",
            "role": "user",
            "points": 100
        }
        self.send_json_response(response)
    
    def handle_locations(self):
        """Handle locations API - GET and POST"""
        if self.command == 'GET':
            # Return mock locations data
            locations = [
                {
                    "id": 1,
                    "name": "Warung Makan Sederhana",
                    "address": "Jl. Sudirman No. 123, Jakarta",
                    "lat": -6.2088,
                    "lng": 106.8456
                },
                {
                    "id": 2,
                    "name": "Restoran Padang Minang",
                    "address": "Jl. Thamrin No. 456, Jakarta",
                    "lat": -6.1944,
                    "lng": 106.8229
                },
                {
                    "id": 3,
                    "name": "Kedai Kopi Kenangan",
                    "address": "Jl. Gatot Subroto No. 789, Jakarta",
                    "lat": -6.2297,
                    "lng": 106.8044
                }
            ]
            self.send_json_response(locations)
        
        elif self.command == 'POST':
            # Mock adding new location
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            location_data = json.loads(post_data.decode('utf-8'))
            
            # In a real app, you'd save to database
            # For now, just return success
            response = {"message": "Location added successfully", "id": 999}
            self.send_json_response(response)
        
        elif self.command == 'DELETE':
            # Mock deleting location
            response = {"message": "Location deleted successfully"}
            self.send_json_response(response)
    
    def handle_upload(self):
        """Handle image upload and ML detection"""
        try:
            print("📸 Received upload request")
            
            # Parse multipart form data
            content_type = self.headers.get('content-type', '')
            if not content_type.startswith('multipart/form-data'):
                self.send_error(400, "Expected multipart/form-data")
                return
            
            # Parse form data
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={'REQUEST_METHOD': 'POST'}
            )
            
            if 'image' not in form:
                self.send_error(400, "No image provided")
                return
            
            file_item = form['image']
            if not file_item.filename:
                self.send_error(400, "No filename provided")
                return
            
            # Generate unique filename
            file_ext = Path(file_item.filename).suffix
            filename = f"{uuid.uuid4().hex}{file_ext}"
            filepath = self.upload_dir / filename
            
            # Save uploaded file
            print(f"💾 Saving image to: {filepath}")
            with open(filepath, 'wb') as f:
                f.write(file_item.file.read())
            
            # Run ML detection
            print("🔍 Running ML detection...")
            detection = self.run_ml_detection(filepath)
            
            # Prepare response
            response = {
                "message": "Upload successful with ML detection",
                "upload_id": str(uuid.uuid4()),
                "points_earned": 10,
                "total_points": 110,
                "image_url": f"/uploads/{filename}",
                "detection": detection,
                "timestamp": datetime.now().isoformat()
            }
            
            print(f"✅ Upload complete: {detection.get('summary', 'No objects detected')}")
            self.send_json_response(response)
            
        except Exception as e:
            print(f"❌ Upload error: {e}")
            self.send_error(500, str(e))
    
    def run_ml_detection(self, image_path):
        """Run YOLO detection on the uploaded image"""
        try:
            # Check if model and script exist
            if not self.model_path.exists():
                return {"error": f"Model not found at {self.model_path}"}
            
            if not self.detect_script.exists():
                return {"error": f"Detection script not found at {self.detect_script}"}
            
            # Generate annotated image path
            annotated_filename = f"det_{image_path.stem}.jpg"
            annotated_path = self.annotated_dir / annotated_filename
            
            # Prepare command
            cmd = [
                sys.executable,
                str(self.detect_script),
                "--model", str(self.model_path),
                "--source", str(image_path),
                "--min_conf", "0.25",
                "--save_annotated", str(annotated_path)
            ]
            
            print(f"🤖 Running: {' '.join(cmd)}")
            
            # Run detection with timeout
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                timeout=60,  # 60 second timeout
                cwd=str(model_dir)
            )
            
            if result.returncode != 0:
                error_msg = result.stderr or "Unknown error"
                print(f"❌ Detection failed: {error_msg}")
                return {"error": f"Detection failed: {error_msg}"}
            
            # Parse JSON output
            stdout = result.stdout.strip()
            if not stdout:
                return {"error": "No output from detection script"}
            
            try:
                detection = json.loads(stdout)
            except json.JSONDecodeError as e:
                return {"error": f"Invalid JSON from detection: {e}"}
            
            # Add annotated URL if available
            if detection.get('annotated_path') and Path(detection['annotated_path']).exists():
                rel_path = Path(detection['annotated_path']).relative_to(Path('foodflow/public'))
                detection['annotated_url'] = f"/{rel_path.as_posix()}"
                print(f"📸 Annotated image saved: {detection['annotated_url']}")
            
            return detection
            
        except subprocess.TimeoutExpired:
            return {"error": "Detection timed out (60s limit)"}
        except Exception as e:
            return {"error": f"Detection error: {str(e)}"}
    
    def send_json_response(self, data):
        """Send JSON response with CORS headers"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode())
    
    def send_cors_headers(self):
        """Send CORS headers"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
    
    def log_message(self, format, *args):
        """Custom log format"""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {format % args}")

def main():
    """Start the ML backend server"""
    port = 3000
    
    print("🚀 Starting FoodFlow ML Backend Server")
    print("=" * 50)
    print(f"📡 Server: http://localhost:{port}")
    print(f"📁 Upload dir: {Path('foodflow/public/uploads').absolute()}")
    print(f"🤖 Model dir: {model_dir.absolute()}")
    print("=" * 50)
    
    # Check dependencies
    try:
        import ultralytics
        print("✅ Ultralytics installed")
    except ImportError:
        print("❌ Ultralytics not installed - run: pip install ultralytics opencv-python")
    
    try:
        import cv2
        print("✅ OpenCV installed")
    except ImportError:
        print("❌ OpenCV not installed - run: pip install opencv-python")
    
    # Check model files
    model_path = model_dir / "train" / "weights" / "best.pt"
    detect_script = model_dir / "detect_api.py"
    
    if model_path.exists():
        print(f"✅ Model found: {model_path}")
    else:
        print(f"❌ Model not found: {model_path}")
    
    if detect_script.exists():
        print(f"✅ Detection script found: {detect_script}")
    else:
        print(f"❌ Detection script not found: {detect_script}")
    
    print("=" * 50)
    print("📸 Ready to process images with ML detection!")
    print("🛑 Press Ctrl+C to stop")
    print()
    
    try:
        server = HTTPServer(('localhost', port), MLHandler)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 Server stopped")
        server.shutdown()

if __name__ == '__main__':
    main()
