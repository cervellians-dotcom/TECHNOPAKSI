# FoodFlow ML Backend

This Python backend handles image uploads and runs YOLO machine learning detection on uploaded images.

## Features

- 🖼️ Image upload handling
- 🤖 YOLO object detection using your trained model
- 📸 Annotated image generation with bounding boxes
- 🌐 CORS-enabled API for web integration
- ⚡ Fast processing with timeout protection

## Setup

1. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Make sure your model files exist:**
   - `../my_model (4)/train/weights/best.pt` (your trained YOLO model)
   - `../my_model (4)/detect_api.py` (detection script)

3. **Start the server:**
   ```bash
   python app.py
   ```

## API Endpoints

- `GET /` - Serves the main FoodFlow website
- `POST /api/uploads` - Upload image and run ML detection
- `POST /api/login` - Mock login (returns test user)
- `GET /api/profile` - Mock profile (returns test user)

## Usage

1. Start the server: `python app.py`
2. Open http://localhost:3000 in your browser
3. Click "Upload Bukti" and select an image
4. The ML model will automatically detect objects and show results

## Response Format

```json
{
  "message": "Upload successful with ML detection",
  "upload_id": "unique-id",
  "points_earned": 10,
  "total_points": 110,
  "image_url": "/uploads/filename.jpg",
  "detection": {
    "objects": [...],
    "counts": {...},
    "summary": "object1: 2, object2: 1",
    "annotated_url": "/uploads/annotated/det_filename.jpg"
  }
}
```

## Troubleshooting

- **"Model not found"**: Check that `../my_model (4)/train/weights/best.pt` exists
- **"Detection script not found"**: Check that `../my_model (4)/detect_api.py` exists
- **"Detection failed"**: Check Python dependencies and model compatibility
- **"Timeout"**: Large images or slow model loading may cause timeouts
